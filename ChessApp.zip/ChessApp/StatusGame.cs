﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessApp
{
    // Represent the current game status with Enum structure
    internal enum StatusGame 
    {
        Draw, Win, InProgress
    }

 }

